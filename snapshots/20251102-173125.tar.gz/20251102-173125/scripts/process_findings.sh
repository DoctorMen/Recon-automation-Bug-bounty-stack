#!/bin/bash
# Process Findings for Submission
# Verifies, filters duplicates, generates reports, prioritizes high-value bugs

cd ~/Recon-automation-Bug-bounty-stack
python3 scripts/process_findings_for_submission.py

