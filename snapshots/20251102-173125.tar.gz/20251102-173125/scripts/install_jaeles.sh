#!/bin/bash
# Install Jaeles - Automated Security Scanner by j3ssie

echo " Installing Jaeles...
