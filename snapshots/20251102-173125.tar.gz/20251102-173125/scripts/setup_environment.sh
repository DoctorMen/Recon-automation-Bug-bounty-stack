#!/bin/bash
# Setup environment with proper screen size and PATH
export COLUMNS=80
export LINES=24
export PATH=/mnt/c/Users/Doc
