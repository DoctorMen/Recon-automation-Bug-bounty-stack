#!/bin/bash
# Install Wappalyzer CLI

echo " Installing Wappalyzer...
