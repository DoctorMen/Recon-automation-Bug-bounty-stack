#!/bin/bash
# Quick script to run parallel setup tasks

cd "$(dirname "$0")/.."
python3 scripts/parallel_setup.py

